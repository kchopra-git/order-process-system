package com.order.system.dto;


public enum Status {

    PENDING,
    PROCESSED,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
