package com.order.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
