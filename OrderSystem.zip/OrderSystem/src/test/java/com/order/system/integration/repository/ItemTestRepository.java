package com.order.system.integration.repository;

import com.order.system.integration.entity.ItemTest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemTestRepository extends JpaRepository<ItemTest,Long> {
}
